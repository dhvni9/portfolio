# Dhvani Gala Portfolio V6

Changes:
- Removed the Images archive from the main page.
- Removed the Services section from the main page.
- Removed Images/Services navigation links.
- Added one representative image to each main case-study card: Fawkes, Bhavika Dedhia Studio, Ce\'la Bakehouse, The Vibe Bags, and The Wedding Diaries.
- Added the same representative image at the top of each expanded case study.
- Kept the Fawkes positioning with Khichdi Bar + Shreya Jaiswal as managed accounts.
